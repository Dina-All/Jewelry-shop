function NotifyUser(){

	alert("You will receive all the new offers in your E-mail!")
}